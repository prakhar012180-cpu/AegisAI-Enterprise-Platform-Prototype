export type PrecisionType = 'FP32' | 'FP16' | 'INT8' | 'INT4';

export interface DetectionObject {
  id: string;
  label: string;
  score: number;
  // Normalized coordinates: [x, y, width, height] (0.0 to 1.0)
  bbox: [number, number, number, number];
  color: string;
  category: 'component' | 'defect' | 'person' | 'package' | 'hazard';
  isDefect?: boolean;
  defectName?: string;
  defectSeverity?: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
}

export interface RegionOfInterest {
  id: string;
  name: string;
  // Normalized coordinates
  x: number;
  y: number;
  width: number;
  height: number;
  color: string;
  enabled: boolean;
  alertOnAnomaly: boolean;
}

export interface InspectionScenario {
  id: string;
  title: string;
  category: 'Electronics AOI' | 'Logistics & Robotics' | 'Workplace Safety' | 'Automotive' | 'Semiconductors';
  industry: string;
  description: string;
  recommendedModel: string;
  baseLatencyMs: number;
  objects: DetectionObject[];
  defectPresent: boolean;
  defectType: string;
  defectSeverity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  standardReference: string;
  rois: RegionOfInterest[];
}

export interface HardwareProfile {
  id: string;
  name: string;
  vendor: 'NVIDIA' | 'Raspberry Pi / Hailo' | 'Google Coral' | 'Intel' | 'Apple' | 'Espressif';
  chipset: string;
  architecture: string;
  tops: number;
  powerTdpWatt: number;
  minWatt: number;
  costUsd: number;
  supportedPrecisions: PrecisionType[];
  defaultPrecision: PrecisionType;
  framework: string;
  formFactor: string;
  memoryMb: number;
  baseLatencyMultiplier: number;
  fpsMultiplier: number;
  idealFor: string;
}

export interface VisionModelSpec {
  id: string;
  name: string;
  family: string;
  task: 'Object Detection' | 'Instance Segmentation' | 'Defect Anomaly' | 'Pose & PPE';
  parametersMillions: number;
  inputResolution: [number, number];
  baseMap50: number; // Mean Average Precision
  modelSizeMb: Record<PrecisionType, number>;
  speedMultiplier: Record<PrecisionType, number>;
  accuracyRetention: Record<PrecisionType, number>; // Percentage
  description: string;
}

export interface EdgeActionRule {
  id: string;
  name: string;
  triggerCondition: 'ANY_DEFECT' | 'CONFIDENCE_BELOW_THRESHOLD' | 'ZONE_BREACH' | 'COUNT_EXCEEDED';
  threshold?: number;
  actionType: 'GPIO_PIN' | 'MQTT_PUBLISH' | 'ALARM_STROBE' | 'GEMINI_CLOUD_AUDIT';
  actionTarget: string;
  enabled: boolean;
  lastTriggered?: string;
}

export interface AuditReport {
  defectIdentified: boolean;
  defectName: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW' | 'NORMAL';
  confidenceScore: number;
  rootCauseAnalysis: string;
  industrialStandard: string;
  recommendedAction: string;
  lineInterventionRequired: boolean;
  estimatedImpact: string;
  verificationNotes: string;
}
