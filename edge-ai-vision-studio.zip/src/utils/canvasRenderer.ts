import { DetectionObject, RegionOfInterest } from '../types/edge';

export interface RenderOptions {
  showBBoxes: boolean;
  showLabels: boolean;
  showHeatmap: boolean;
  showRois: boolean;
  showHudReticle: boolean;
  confidenceThreshold: number;
}

export function drawInspectionCanvas(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  scenarioId: string,
  userImage: HTMLImageElement | null,
  videoElement: HTMLVideoElement | null,
  objects: DetectionObject[],
  rois: RegionOfInterest[],
  options: RenderOptions,
  frameTick: number = 0
) {
  // Clear canvas
  ctx.clearRect(0, 0, width, height);

  // 1. Draw Background Source
  if (videoElement && videoElement.readyState >= 2) {
    ctx.drawImage(videoElement, 0, 0, width, height);
  } else if (userImage && userImage.complete) {
    ctx.drawImage(userImage, 0, 0, width, height);
  } else {
    // Render Procedural High-Fidelity Synthetic Industrial Scenario
    renderProceduralScenario(ctx, width, height, scenarioId, frameTick);
  }

  // 2. Render Anomaly Heatmap (if enabled and defects present)
  if (options.showHeatmap) {
    renderDefectHeatmap(ctx, width, height, objects);
  }

  // 3. Render Regions of Interest (ROIs)
  if (options.showRois) {
    renderRois(ctx, width, height, rois);
  }

  // 4. Render Bounding Boxes
  if (options.showBBoxes) {
    renderBoundingBoxes(ctx, width, height, objects, options.showLabels, options.confidenceThreshold, frameTick);
  }

  // 5. Render HUD Reticles & Industrial Diagnostics
  if (options.showHudReticle) {
    renderHudOverlay(ctx, width, height, frameTick);
  }
}

function renderProceduralScenario(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  scenarioId: string,
  frameTick: number
) {
  ctx.save();

  if (scenarioId === 'pcb-aoi') {
    // PCB Substrate: Deep industrial forest green
    ctx.fillStyle = '#062817';
    ctx.fillRect(0, 0, w, h);

    // Copper Ground Plane Grid
    ctx.strokeStyle = '#0d4a2b';
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 28) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 28) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // Gold Circuit Traces
    ctx.strokeStyle = '#eab308';
    ctx.lineWidth = 2;
    ctx.beginPath();
    // Trace 1
    ctx.moveTo(w * 0.1, h * 0.3);
    ctx.lineTo(w * 0.2, h * 0.3);
    ctx.lineTo(w * 0.22, h * 0.4);
    // Trace 2
    ctx.moveTo(w * 0.22, h * 0.55);
    ctx.lineTo(w * 0.22, h * 0.8);
    ctx.lineTo(w * 0.35, h * 0.8);
    // Trace 3
    ctx.moveTo(w * 0.52, h * 0.44);
    ctx.lineTo(w * 0.65, h * 0.44);
    ctx.lineTo(w * 0.65, h * 0.32);
    // Trace 4
    ctx.moveTo(w * 0.74, h * 0.34);
    ctx.lineTo(w * 0.85, h * 0.34);
    ctx.lineTo(w * 0.85, h * 0.7);
    ctx.stroke();

    // Silkscreen Text
    ctx.fillStyle = '#ffffff';
    ctx.font = '10px monospace';
    ctx.fillText('REV 3.2 • EDGE_AI_VISION AOI', w * 0.05, h * 0.12);
    ctx.fillText('U1 [MCU-48]', w * 0.25, h * 0.24);
    ctx.fillText('C12', w * 0.66, h * 0.28);
    ctx.fillText('C14', w * 0.78, h * 0.28);
    ctx.fillText('Y1 [24MHz]', w * 0.67, h * 0.46);

    // QFP-48 IC Body (U1)
    const qfpX = w * 0.24;
    const qfpY = h * 0.28;
    const qfpW = w * 0.26;
    const qfpH = h * 0.32;

    // IC Chip Case
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(qfpX, qfpY, qfpW, qfpH);
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 2;
    ctx.strokeRect(qfpX, qfpY, qfpW, qfpH);

    // Chip Orientation Dot
    ctx.fillStyle = '#64748b';
    ctx.beginPath();
    ctx.arc(qfpX + 16, qfpY + 16, 4, 0, Math.PI * 2);
    ctx.fill();

    // IC Laser Marking
    ctx.fillStyle = '#94a3b8';
    ctx.font = '11px monospace';
    ctx.fillText('ARM CORTEX-M7', qfpX + 22, qfpY + qfpH * 0.45);
    ctx.fillText('STM32H743', qfpX + 32, qfpY + qfpH * 0.65);

    // QFP Pins (Left & Right)
    const pinCount = 10;
    const pinGap = qfpH / (pinCount + 1);
    for (let i = 1; i <= pinCount; i++) {
      const pinY = qfpY + i * pinGap;
      // Left pins
      ctx.fillStyle = '#cbd5e1';
      ctx.fillRect(qfpX - 16, pinY - 2, 16, 5);
      // Right pins
      ctx.fillRect(qfpX + qfpW, pinY - 2, 16, 5);
      // Solder pads
      ctx.fillStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.arc(qfpX - 18, pinY, 4, 0, Math.PI * 2);
      ctx.arc(qfpX + qfpW + 18, pinY, 4, 0, Math.PI * 2);
      ctx.fill();
    }

    // DEFECT: Solder Bridge on Left Pins 6 & 7
    const defPinY1 = qfpY + 6 * pinGap;
    const defPinY2 = qfpY + 7 * pinGap;
    ctx.fillStyle = '#ef4444'; // Red solder bridge highlight
    ctx.beginPath();
    ctx.ellipse(qfpX - 16, (defPinY1 + defPinY2) / 2, 9, 14, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#fca5a5';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    // Capacitors (C12, C14)
    drawSmdCapacitor(ctx, w * 0.66, h * 0.31, 28, 16);
    drawSmdCapacitor(ctx, w * 0.78, h * 0.31, 32, 18);

    // Crystal Oscillator (Metal can)
    ctx.fillStyle = '#94a3b8';
    ctx.roundRect(w * 0.67, h * 0.49, w * 0.16, h * 0.10, 6);
    ctx.fill();
    ctx.strokeStyle = '#cbd5e1';
    ctx.stroke();
    ctx.fillStyle = '#334155';
    ctx.font = '9px monospace';
    ctx.fillText('24.000 MHz', w * 0.69, h * 0.55);

  } else if (scenarioId === 'warehouse-robotics') {
    // Conveyor Belt Dark Rubber Texture
    ctx.fillStyle = '#111827';
    ctx.fillRect(0, 0, w, h);

    // Conveyor Rollers / Grooves
    const beltShift = (frameTick * 2) % 40;
    ctx.strokeStyle = '#1f2937';
    ctx.lineWidth = 3;
    for (let y = -40 + beltShift; y < h + 40; y += 40) {
      ctx.beginPath();
      ctx.moveTo(w * 0.08, y);
      ctx.lineTo(w * 0.92, y);
      ctx.stroke();
    }

    // Steel Side Guardrails
    ctx.fillStyle = '#374151';
    ctx.fillRect(0, 0, w * 0.08, h);
    ctx.fillRect(w * 0.92, 0, w * 0.08, h);

    // Carton Box #1 (Cardboard brown)
    const boxX = w * 0.20;
    const boxY = h * 0.24;
    const boxW = w * 0.32;
    const boxH = h * 0.38;

    ctx.fillStyle = '#b45309';
    ctx.fillRect(boxX, boxY, boxW, boxH);
    ctx.strokeStyle = '#78350f';
    ctx.lineWidth = 3;
    ctx.strokeRect(boxX, boxY, boxW, boxH);

    // Tape across center
    ctx.fillStyle = '#ca8a04';
    ctx.fillRect(boxX, boxY + boxH * 0.46, boxW, 16);

    // DEFECT: Torn/punctured seal on top flap
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.moveTo(boxX + 20, boxY + 8);
    ctx.lineTo(boxX + 65, boxY + 28);
    ctx.lineTo(boxX + 50, boxY + 48);
    ctx.lineTo(boxX + 15, boxY + 22);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 1;
    ctx.stroke();

    // Barcode on box
    drawBarcode(ctx, boxX + boxW * 0.45, boxY + boxH * 0.60, 60, 28);

    // Carton Box #2 (Polybag mailer)
    ctx.fillStyle = '#e2e8f0';
    ctx.roundRect(w * 0.62, h * 0.34, w * 0.25, h * 0.32, 12);
    ctx.fill();
    ctx.strokeStyle = '#cbd5e1';
    ctx.stroke();
    drawBarcode(ctx, w * 0.66, h * 0.45, 54, 24);

  } else if (scenarioId === 'workplace-ppe') {
    // Concrete Shop Floor
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, 0, w, h);

    // Yellow Hazard Stripe Border
    renderHazardStripes(ctx, w * 0.35, h * 0.18, w * 0.55, h * 0.68);

    // Robot Base Pedestal
    ctx.fillStyle = '#0f172a';
    ctx.fillRect(w * 0.62, h * 0.58, 80, 50);

    // KUKA / Fanuc Industrial Robot Arm (Orange joints)
    ctx.strokeStyle = '#ea580c';
    ctx.lineWidth = 18;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(w * 0.66, h * 0.60);
    ctx.lineTo(w * 0.68, h * 0.42);
    ctx.lineTo(w * 0.78, h * 0.32);
    ctx.stroke();

    // Robot Tool End Effector (Welder torch)
    ctx.fillStyle = '#94a3b8';
    ctx.beginPath();
    ctx.arc(w * 0.78, h * 0.32, 14, 0, Math.PI * 2);
    ctx.fill();

    // Worker Operator (Stylized industrial avatar)
    const workerX = w * 0.44;
    const workerY = h * 0.42;

    // Hardhat (Compliant white)
    ctx.fillStyle = '#f8fafc';
    ctx.beginPath();
    ctx.ellipse(workerX, workerY - 18, 12, 8, 0, 0, Math.PI * 2);
    ctx.fill();

    // Head
    ctx.fillStyle = '#fbcfe8';
    ctx.beginPath();
    ctx.arc(workerX, workerY - 8, 9, 0, Math.PI * 2);
    ctx.fill();

    // Torso WITHOUT High-Vis vest (Dark grey hoodie - violation)
    ctx.fillStyle = '#334155';
    ctx.fillRect(workerX - 14, workerY + 2, 28, 48);

    // Violation red pulse outline
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2;
    ctx.strokeRect(workerX - 16, workerY, 32, 52);

    // Legs
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(workerX - 12, workerY + 50, 10, 42);
    ctx.fillRect(workerX + 2, workerY + 50, 10, 42);

  } else if (scenarioId === 'automotive-welding') {
    // Brushed Sheet Metal Steel Plate
    ctx.fillStyle = '#334155';
    ctx.fillRect(0, 0, w, h);

    // Laser Weld Bead (Silver ripple line)
    const weldY = h * 0.50;
    ctx.strokeStyle = '#64748b';
    ctx.lineWidth = 26;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(w * 0.18, weldY);
    ctx.lineTo(w * 0.82, weldY);
    ctx.stroke();

    // Weld bead overlapping fish scales
    for (let x = w * 0.20; x < w * 0.80; x += 14) {
      ctx.fillStyle = '#94a3b8';
      ctx.beginPath();
      ctx.ellipse(x, weldY, 8, 12, 0, 0, Math.PI * 2);
      ctx.fill();
    }

    // DEFECT: Surface Porosity Void
    ctx.fillStyle = '#0f172a';
    ctx.beginPath();
    ctx.arc(w * 0.50, weldY, 9, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    // Crack propagation line
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(w * 0.50 + 8, weldY - 4);
    ctx.lineTo(w * 0.53, weldY - 14);
    ctx.stroke();

  } else {
    // Silicon Wafer (Deep iridescent rainbow metallic disc)
    ctx.fillStyle = '#090d16';
    ctx.fillRect(0, 0, w, h);

    const centerX = w * 0.5;
    const centerY = h * 0.5;
    const radius = Math.min(w, h) * 0.44;

    // Wafer Disc
    const grad = ctx.createRadialGradient(centerX, centerY, 40, centerX, centerY, radius);
    grad.addColorStop(0, '#1e1b4b');
    grad.addColorStop(0.5, '#0f172a');
    grad.addColorStop(1, '#020617');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = '#38bdf8';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Micro-Die Matrix Grid
    ctx.strokeStyle = '#1e293b';
    ctx.lineWidth = 1;
    const dieSize = 36;
    for (let x = centerX - radius; x < centerX + radius; x += dieSize) {
      for (let y = centerY - radius; y < centerY + radius; y += dieSize) {
        if (Math.hypot(x - centerX, y - centerY) < radius - 15) {
          ctx.strokeRect(x, y, dieSize - 2, dieSize - 2);
        }
      }
    }

    // DEFECT: Micro-scratch across central die
    ctx.strokeStyle = '#ef4444';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(centerX - 35, centerY - 25);
    ctx.lineTo(centerX + 40, centerY + 15);
    ctx.stroke();
  }

  ctx.restore();
}

function drawSmdCapacitor(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  // Ceramic body
  ctx.fillStyle = '#b45309';
  ctx.fillRect(x, y, w, h);
  // Silver end terminations
  ctx.fillStyle = '#e2e8f0';
  ctx.fillRect(x, y, 6, h);
  ctx.fillRect(x + w - 6, y, 6, h);
  ctx.strokeStyle = '#64748b';
  ctx.lineWidth = 1;
  ctx.strokeRect(x, y, w, h);
}

function drawBarcode(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(x, y, w, h);
  ctx.fillStyle = '#000000';
  const barWidths = [2, 1, 3, 1, 2, 4, 1, 2, 1, 3, 2, 1, 4, 2];
  let curX = x + 4;
  for (let i = 0; i < barWidths.length && curX < x + w - 4; i++) {
    const bw = barWidths[i % barWidths.length];
    if (i % 2 === 0) {
      ctx.fillRect(curX, y + 2, bw, h - 8);
    }
    curX += bw + 1;
  }
}

function renderHazardStripes(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number) {
  ctx.strokeStyle = '#ca8a04';
  ctx.lineWidth = 3;
  ctx.setLineDash([8, 8]);
  ctx.strokeRect(x, y, w, h);
  ctx.setLineDash([]);
}

function renderDefectHeatmap(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  objects: DetectionObject[]
) {
  const defect = objects.find((o) => o.isDefect);
  if (!defect) return;

  const [bx, by, bw, bh] = defect.bbox;
  const cx = (bx + bw / 2) * w;
  const cy = (by + bh / 2) * h;
  const radius = Math.max(bw * w, bh * h) * 1.4;

  ctx.save();
  const grad = ctx.createRadialGradient(cx, cy, 2, cx, cy, radius);
  grad.addColorStop(0, 'rgba(239, 68, 68, 0.7)');
  grad.addColorStop(0.3, 'rgba(249, 115, 22, 0.5)');
  grad.addColorStop(0.7, 'rgba(234, 179, 8, 0.25)');
  grad.addColorStop(1, 'rgba(59, 130, 246, 0.0)');

  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

function renderRois(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  rois: RegionOfInterest[]
) {
  ctx.save();
  for (const roi of rois) {
    if (!roi.enabled) continue;
    const rx = roi.x * w;
    const ry = roi.y * h;
    const rw = roi.width * w;
    const rh = roi.height * h;

    // ROI Box Dashed
    ctx.strokeStyle = roi.color;
    ctx.lineWidth = 1.5;
    ctx.setLineDash([5, 5]);
    ctx.strokeRect(rx, ry, rw, rh);
    ctx.setLineDash([]);

    // Fill subtle tint
    ctx.fillStyle = roi.color + '12';
    ctx.fillRect(rx, ry, rw, rh);

    // Header Tag
    ctx.fillStyle = roi.color;
    ctx.font = '10px monospace';
    const tag = `ROI: ${roi.name}`;
    const textWidth = ctx.measureText(tag).width;
    ctx.fillRect(rx, ry - 16, textWidth + 10, 16);
    ctx.fillStyle = '#090d16';
    ctx.fillText(tag, rx + 5, ry - 4);
  }
  ctx.restore();
}

function renderBoundingBoxes(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  objects: DetectionObject[],
  showLabels: boolean,
  threshold: number,
  frameTick: number
) {
  ctx.save();

  for (const obj of objects) {
    if (obj.score < threshold) continue;

    const [bx, by, bw, bh] = obj.bbox;
    const x = bx * w;
    const y = by * h;
    const boxW = bw * w;
    const boxH = bh * h;

    const isDefect = obj.isDefect;
    const baseColor = isDefect ? '#ef4444' : obj.color || '#06b6d4';

    // Defect Pulsing Glow
    if (isDefect) {
      const pulseAlpha = 0.2 + 0.15 * Math.sin(frameTick * 0.15);
      ctx.fillStyle = `rgba(239, 68, 68, ${pulseAlpha})`;
      ctx.fillRect(x, y, boxW, boxH);
    }

    // Modern Corner-bracket Bounding Box
    const cornerLen = Math.min(14, boxW / 3, boxH / 3);
    ctx.strokeStyle = baseColor;
    ctx.lineWidth = isDefect ? 2.5 : 2;

    // Top-left
    ctx.beginPath();
    ctx.moveTo(x, y + cornerLen);
    ctx.lineTo(x, y);
    ctx.lineTo(x + cornerLen, y);
    // Top-right
    ctx.moveTo(x + boxW - cornerLen, y);
    ctx.lineTo(x + boxW, y);
    ctx.lineTo(x + boxW, y + cornerLen);
    // Bottom-right
    ctx.moveTo(x + boxW, y + boxH - cornerLen);
    ctx.lineTo(x + boxW, y + boxH);
    ctx.lineTo(x + boxW - cornerLen, y + boxH);
    // Bottom-left
    ctx.moveTo(x + cornerLen, y + boxH);
    ctx.lineTo(x, y + boxH);
    ctx.lineTo(x, y + boxH - cornerLen);
    ctx.stroke();

    // Subtle center crosshair for target
    ctx.strokeStyle = baseColor + '60';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x + boxW / 2 - 4, y + boxH / 2);
    ctx.lineTo(x + boxW / 2 + 4, y + boxH / 2);
    ctx.moveTo(x + boxW / 2, y + boxH / 2 - 4);
    ctx.lineTo(x + boxW / 2, y + boxH / 2 + 4);
    ctx.stroke();

    // Label Badge
    if (showLabels) {
      ctx.font = '11px monospace';
      const labelText = `${obj.label} ${(obj.score * 100).toFixed(0)}%`;
      const textWidth = ctx.measureText(labelText).width;
      const tagH = 18;

      ctx.fillStyle = isDefect ? '#ef4444' : '#0f172a';
      ctx.fillRect(x, Math.max(0, y - tagH), textWidth + 10, tagH);

      ctx.strokeStyle = baseColor;
      ctx.lineWidth = 1;
      ctx.strokeRect(x, Math.max(0, y - tagH), textWidth + 10, tagH);

      ctx.fillStyle = isDefect ? '#ffffff' : '#f8fafc';
      ctx.fillText(labelText, x + 5, Math.max(12, y - 4));
    }
  }

  ctx.restore();
}

function renderHudOverlay(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  frameTick: number
) {
  ctx.save();

  // Center Reticle
  const cx = w / 2;
  const cy = h / 2;
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.25)';
  ctx.lineWidth = 1;

  // Outer cross
  ctx.beginPath();
  ctx.moveTo(cx - 20, cy);
  ctx.lineTo(cx + 20, cy);
  ctx.moveTo(cx, cy - 20);
  ctx.lineTo(cx, cy + 20);
  ctx.stroke();

  // Corner brackets for overall frame
  const frameBracket = 24;
  ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
  ctx.lineWidth = 1.5;

  ctx.beginPath();
  // Top-left
  ctx.moveTo(12, 12 + frameBracket);
  ctx.lineTo(12, 12);
  ctx.lineTo(12 + frameBracket, 12);
  // Top-right
  ctx.moveTo(w - 12 - frameBracket, 12);
  ctx.lineTo(w - 12, 12);
  ctx.lineTo(w - 12, 12 + frameBracket);
  // Bottom-left
  ctx.moveTo(12, h - 12 - frameBracket);
  ctx.lineTo(12, h - 12);
  ctx.lineTo(12 + frameBracket, h - 12);
  // Bottom-right
  ctx.moveTo(w - 12 - frameBracket, h - 12);
  ctx.lineTo(w - 12, h - 12);
  ctx.lineTo(w - 12, h - 12 - frameBracket);
  ctx.stroke();

  // Frame tick counter in lower left
  ctx.fillStyle = 'rgba(148, 163, 184, 0.6)';
  ctx.font = '10px monospace';
  ctx.fillText(`FRAME #${String(frameTick).padStart(6, '0')}`, 16, h - 20);

  ctx.restore();
}
