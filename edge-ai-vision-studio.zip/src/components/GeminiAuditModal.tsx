import React from 'react';
import { 
  Sparkles, 
  X, 
  AlertTriangle, 
  CheckCircle2, 
  ShieldAlert, 
  Download, 
  Wrench, 
  BookOpen, 
  Cpu, 
  Zap, 
  TrendingDown,
  Printer
} from 'lucide-react';
import { AuditReport, InspectionScenario } from '../types/edge';

interface GeminiAuditModalProps {
  isOpen: boolean;
  onClose: () => void;
  report: AuditReport | null;
  isLoading: boolean;
  capturedFrame: string | null;
  scenario: InspectionScenario | null;
  onAcknowledgeAction?: () => void;
}

export const GeminiAuditModal: React.FC<GeminiAuditModalProps> = ({
  isOpen,
  onClose,
  report,
  isLoading,
  capturedFrame,
  scenario,
  onAcknowledgeAction,
}) => {
  if (!isOpen) return null;

  const downloadReportJson = () => {
    if (!report) return;
    const data = {
      auditTimestamp: new Date().toISOString(),
      auditor: 'Gemini 3.8 Flash Multimodal Vision API',
      inspectionScenario: scenario?.title,
      standardReference: scenario?.standardReference,
      findings: report,
    };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `gemini_vision_audit_report_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-2xl border border-slate-700 bg-[#080d1a] shadow-2xl overflow-hidden my-8">
        {/* Modal Top Header */}
        <div className="flex items-center justify-between border-b border-slate-800 bg-slate-900/90 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-indigo-500/20 border border-indigo-500/40 text-indigo-400">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-bold text-white">
                  Gemini Deep Vision Audit & Root Cause Analysis
                </h3>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-indigo-950 text-indigo-300 border border-indigo-700">
                  gemini-3.8-flash
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Automated optical inspection triage · Industrial compliance RCA
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6 max-h-[75vh] overflow-y-auto">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-16 space-y-4">
              <div className="relative flex h-16 w-16">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-indigo-500 opacity-75"></span>
                <span className="relative inline-flex h-16 w-16 items-center justify-center rounded-full bg-indigo-600 text-white">
                  <Sparkles className="h-8 w-8 animate-spin" />
                </span>
              </div>
              <div className="text-center">
                <h4 className="text-sm font-bold text-white">Analyzing Edge Frame with Gemini Multimodal Vision...</h4>
                <p className="text-xs text-slate-400 mt-1 max-w-md">
                  Correlating pixel anomaly saliency with manufacturing standard databases (IPC-A-610, ISO 9001, OSHA 1910).
                </p>
              </div>
            </div>
          ) : report ? (
            <>
              {/* Snapshot + Quick Verdict Summary Grid */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
                {/* Captured Frame Thumbnail (5 cols) */}
                <div className="md:col-span-5 space-y-2">
                  <span className="text-[11px] font-mono font-semibold text-slate-400 uppercase tracking-wider block">
                    INSPECTION SNAPSHOT
                  </span>
                  <div className="relative aspect-video rounded-xl border border-slate-700 overflow-hidden bg-black flex items-center justify-center">
                    {capturedFrame ? (
                      <img
                        src={capturedFrame}
                        alt="Audited Edge Frame"
                        className="h-full w-full object-contain"
                      />
                    ) : (
                      <div className="text-xs text-slate-500 font-mono">No Frame Captured</div>
                    )}
                    <div className="scanline-overlay absolute inset-0 pointer-events-none opacity-30" />
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono flex justify-between">
                    <span>Target: {scenario?.category}</span>
                    <span>Confidence: {(report.confidenceScore * 100).toFixed(0)}%</span>
                  </div>
                </div>

                {/* Verdict Readout (7 cols) */}
                <div className="md:col-span-7 space-y-3">
                  <div className={`rounded-xl border p-4 ${
                    report.defectIdentified
                      ? report.severity === 'CRITICAL'
                        ? 'bg-rose-950/40 border-rose-700/60'
                        : 'bg-amber-950/40 border-amber-700/60'
                      : 'bg-emerald-950/40 border-emerald-700/60'
                  }`}>
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                        AUDIT VERDICT & CLASSIFICATION
                      </span>
                      <span className={`text-xs font-mono font-bold px-2.5 py-0.5 rounded ${
                        report.severity === 'CRITICAL'
                          ? 'bg-rose-600 text-white'
                          : report.severity === 'HIGH'
                          ? 'bg-amber-600 text-white'
                          : 'bg-emerald-600 text-white'
                      }`}>
                        {report.severity} SEVERITY
                      </span>
                    </div>

                    <h4 className="text-base font-bold text-white mt-1">
                      {report.defectName}
                    </h4>

                    <div className="flex items-center gap-2 mt-2 text-xs font-mono text-slate-300">
                      <BookOpen className="h-3.5 w-3.5 text-cyan-400 shrink-0" />
                      <span>{report.industrialStandard}</span>
                    </div>
                  </div>

                  {report.lineInterventionRequired && (
                    <div className="flex items-center gap-3 rounded-xl border border-rose-600/50 bg-rose-950/60 p-3 text-xs text-rose-200">
                      <ShieldAlert className="h-5 w-5 text-rose-400 shrink-0" />
                      <div>
                        <strong>Physical Line Intervention Required:</strong> Halting continuous infeed or dispatching reject actuator is recommended.
                      </div>
                    </div>
                  )}

                  <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 text-xs space-y-1">
                    <span className="text-[10px] font-mono text-slate-500 uppercase">Yield & Quality Impact</span>
                    <p className="text-slate-200 leading-relaxed font-sans">{report.estimatedImpact}</p>
                  </div>
                </div>
              </div>

              {/* Deep Root Cause Analysis Narrative */}
              <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-2">
                <h4 className="text-xs font-semibold text-cyan-300 uppercase tracking-wider flex items-center gap-2 font-mono">
                  <Wrench className="h-4 w-4 text-cyan-400" />
                  Engineering Root Cause Analysis (RCA)
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed font-sans whitespace-pre-line">
                  {report.rootCauseAnalysis}
                </p>
              </div>

              {/* Prescriptive Remediation Actions */}
              <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-5 space-y-2">
                <h4 className="text-xs font-semibold text-emerald-400 uppercase tracking-wider flex items-center gap-2 font-mono">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  Recommended Corrective Actions for Line Technicians
                </h4>
                <p className="text-xs text-slate-200 leading-relaxed font-sans whitespace-pre-line">
                  {report.recommendedAction}
                </p>
              </div>

              {/* Optical Verification Notes */}
              {report.verificationNotes && (
                <div className="text-[11px] text-slate-400 font-mono bg-slate-950/60 p-3 rounded-lg border border-slate-800">
                  <span className="text-slate-500">OPTICAL NOTES: </span>
                  {report.verificationNotes}
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-12 text-slate-400 text-xs">
              No audit report generated. Click "Audit Frame" on the Vision Inspector to start.
            </div>
          )}
        </div>

        {/* Modal Bottom Actions */}
        <div className="flex flex-wrap items-center justify-between border-t border-slate-800 bg-slate-900/90 px-6 py-4 gap-3">
          <div className="flex items-center gap-2">
            <button
              onClick={downloadReportJson}
              disabled={!report}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors disabled:opacity-40"
            >
              <Download className="h-3.5 w-3.5" />
              Download JSON Report
            </button>
            <button
              onClick={handlePrint}
              disabled={!report}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors disabled:opacity-40"
            >
              <Printer className="h-3.5 w-3.5" />
              Print / PDF
            </button>
          </div>

          <div className="flex items-center gap-2">
            {report?.defectIdentified && (
              <button
                onClick={() => {
                  onAcknowledgeAction?.();
                  onClose();
                }}
                className="flex items-center gap-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 px-4 py-2 text-xs font-semibold text-white shadow-md transition-colors"
              >
                <Zap className="h-3.5 w-3.5" />
                Actuate Pneumatic Diverter (GPIO 17)
              </button>
            )}
            <button
              onClick={onClose}
              className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white text-xs font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
