import React, { useState } from 'react';
import { 
  Sliders, 
  ArrowRight, 
  Copy, 
  Check, 
  Download, 
  Code, 
  Layers, 
  Cpu, 
  HardDrive, 
  Gauge, 
  FileCode,
  Sparkles
} from 'lucide-react';
import { VisionModelSpec, PrecisionType, HardwareProfile } from '../types/edge';
import { VISION_MODELS } from '../data/hardwareProfiles';

interface QuantizationStudioProps {
  activeModel: VisionModelSpec;
  setActiveModel: (model: VisionModelSpec) => void;
  activePrecision: PrecisionType;
  setActivePrecision: (precision: PrecisionType) => void;
  activeHardware: HardwareProfile;
}

export const QuantizationStudio: React.FC<QuantizationStudioProps> = ({
  activeModel,
  setActiveModel,
  activePrecision,
  setActivePrecision,
  activeHardware,
}) => {
  const [copiedCode, setCopiedCode] = useState<boolean>(false);
  const [exportFramework, setExportFramework] = useState<'tensorrt' | 'openvino' | 'hailo' | 'tflite'>('tensorrt');

  // Precision metrics
  const modelSize = activeModel.modelSizeMb[activePrecision];
  const speedup = activeModel.speedMultiplier[activePrecision];
  const accRetention = activeModel.accuracyRetention[activePrecision];
  const estLatency = (8.5 * activeHardware.baseLatencyMultiplier / speedup).toFixed(1);

  // Python Deployment Code Snippet
  const getDeploymentSnippet = () => {
    if (exportFramework === 'tensorrt') {
      return `import tensorrt as trt
import pycuda.driver as cuda
import pycuda.autoinit
import cv2
import numpy as np

# Load compiled TensorRT Engine for ${activeHardware.name}
TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
with open("${activeModel.id}_${activePrecision.toLowerCase()}.engine", "rb") as f:
    runtime = trt.Runtime(TRT_LOGGER)
    engine = runtime.deserialize_cuda_engine(f.read())
    context = engine.create_execution_context()

def infer_frame(frame: np.ndarray):
    # Preprocessing: Letterbox to ${activeModel.inputResolution[0]}x${activeModel.inputResolution[1]}
    resized = cv2.resize(frame, (${activeModel.inputResolution[0]}, ${activeModel.inputResolution[1]}))
    blob = resized.astype(np.float32) / 255.0
    blob = np.transpose(blob, (2, 0, 1))[None, ...]
    
    # Execute Edge TensorRT Inference
    bindings = [int(cuda.mem_alloc(blob.nbytes))]
    cuda.memcpy_htod(bindings[0], np.ascontiguousarray(blob))
    context.execute_v2(bindings=bindings)
    return "Detections parsed with NMS"
`;
    } else if (exportFramework === 'openvino') {
      return `from openvino.runtime import Core
import cv2
import numpy as np

# Initialize OpenVINO 2025 Runtime on ${activeHardware.name}
core = Core()
model = core.read_model("${activeModel.id}_${activePrecision.toLowerCase()}.xml")
compiled_model = core.compile_model(model, device_name="GPU" if "Arc" in "${activeHardware.name}" else "CPU")

infer_request = compiled_model.create_infer_request()
cap = cv2.VideoCapture(0)

while cap.isOpened():
    ret, frame = cap.read()
    if not ret: break
    
    # Forward Pass through OpenVINO
    input_tensor = cv2.resize(frame, (${activeModel.inputResolution[0]}, ${activeModel.inputResolution[1]}))
    results = infer_request.infer(inputs={0: input_tensor[None, ...]})
    # Extract bounding boxes and confidence scores
`;
    } else if (exportFramework === 'hailo') {
      return `from hailo_platform import VDevice, HailoStreamInterface, ConfigureParams
import numpy as np

# Initialize Hailo-8 M.2 PCIe Device
params = VDevice.create_params()
with VDevice(params) as target:
    # Load calibrated HEF binary (${activePrecision} quantized)
    hef = HEF("${activeModel.id}.hef")
    configure_params = ConfigureParams.create_from_hef(hef, interface=HailoStreamInterface.PCIe)
    network_group = target.configure(hef, configure_params)[0]
    
    with network_group.activate():
        # High-throughput asynchronous pipeline (160+ FPS)
        print("Hailo-8 hardware pipeline active on Raspberry Pi 5")
`;
    } else {
      return `import tflite_runtime.interpreter as tflite
import numpy as np

# Initialize TensorFlow Lite EdgeTPU runtime
try:
    from pycoral.utils.edgetpu import make_interpreter
    interpreter = make_interpreter("${activeModel.id}_edgetpu.tflite")
except ImportError:
    interpreter = tflite.Interpreter(model_path="${activeModel.id}_int8.tflite")

interpreter.allocate_tensors()
input_details = interpreter.get_input_details()
output_details = interpreter.get_output_details()
print("EdgeTPU Model Loaded Successfully")
`;
    }
  };

  const copyCode = () => {
    navigator.clipboard.writeText(getDeploymentSnippet());
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadManifest = () => {
    const manifest = {
      modelName: activeModel.name,
      modelId: activeModel.id,
      architecture: activeModel.family,
      targetHardware: activeHardware.name,
      precision: activePrecision,
      inputResolution: activeModel.inputResolution,
      metrics: {
        modelSizeMb: modelSize,
        speedupMultiplier: speedup,
        accuracyRetentionPct: accRetention,
        estimatedLatencyMs: estLatency,
      },
      exportFramework,
      calibrationProfile: {
        method: activePrecision === 'INT8' ? 'Entropy Calibration (KL Divergence)' : 'None',
        quantizationNoiseDelta: activePrecision === 'INT4' ? '±3.8%' : activePrecision === 'INT8' ? '±0.4%' : '0%',
      },
    };

    const blob = new Blob([JSON.stringify(manifest, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${activeModel.id}_${activePrecision.toLowerCase()}_edge_config.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-8">
      {/* Top Studio Title */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Sliders className="h-5 w-5 text-cyan-400" />
            Model Quantization & Edge Deployment Pipeline
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Optimize neural weights across precision tiers (FP32, FP16, INT8, INT4) and generate production edge runtimes.
          </p>
        </div>

        <button
          onClick={handleDownloadManifest}
          className="flex items-center gap-2 rounded-lg bg-cyan-600 hover:bg-cyan-500 px-4 py-2 text-xs font-semibold text-white shadow-sm transition-colors"
        >
          <Download className="h-3.5 w-3.5" />
          Export Edge Manifest (.json)
        </button>
      </div>

      {/* Model Selection Tabs */}
      <div className="space-y-3">
        <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
          1. Select Vision Model Architecture
        </span>
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {VISION_MODELS.map((model) => {
            const isSelected = activeModel.id === model.id;
            return (
              <button
                key={model.id}
                onClick={() => setActiveModel(model)}
                className={`p-3.5 rounded-xl border text-left transition-all ${
                  isSelected
                    ? 'bg-slate-900 border-cyan-500/80 shadow-md shadow-cyan-500/10'
                    : 'bg-slate-900/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900/70'
                }`}
              >
                <div className="text-[10px] font-mono text-cyan-400 mb-1">{model.task}</div>
                <div className="text-xs font-bold text-white mb-1">{model.name}</div>
                <div className="text-[10px] text-slate-400 font-mono">
                  {model.parametersMillions}M Params · {model.inputResolution[0]}x{model.inputResolution[1]}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Precision Selection Tier */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider">
            2. Choose Quantization Precision Tier
          </span>
          <span className="text-xs text-slate-400 font-mono">
            Target HW: <strong className="text-cyan-300">{activeHardware.name}</strong>
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {(['FP32', 'FP16', 'INT8', 'INT4'] as PrecisionType[]).map((prec) => {
            const isSelected = activePrecision === prec;
            const isSupported = activeHardware.supportedPrecisions.includes(prec);
            const size = activeModel.modelSizeMb[prec];
            const spd = activeModel.speedMultiplier[prec];
            const acc = activeModel.accuracyRetention[prec];

            return (
              <div
                key={prec}
                onClick={() => isSupported && setActivePrecision(prec)}
                className={`rounded-xl border p-4 transition-all relative ${
                  !isSupported
                    ? 'opacity-40 cursor-not-allowed bg-slate-950/40 border-slate-900'
                    : isSelected
                    ? 'cursor-pointer bg-slate-900 border-cyan-500 shadow-lg shadow-cyan-500/15'
                    : 'cursor-pointer bg-slate-900/40 border-slate-800 hover:border-slate-700'
                }`}
              >
                {!isSupported && (
                  <span className="absolute top-2 right-2 text-[9px] font-mono text-slate-500 bg-slate-800 px-1.5 py-0.5 rounded">
                    Unsupported on HW
                  </span>
                )}

                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-bold font-mono text-white">{prec}</span>
                  <span className="text-[10px] font-mono text-cyan-400">
                    {prec === 'FP32' ? 'Full IEEE 754' : prec === 'FP16' ? 'Half Precision' : prec === 'INT8' ? 'PTQ Quantized' : 'Weight AWQ'}
                  </span>
                </div>

                <div className="space-y-2 border-t border-slate-800/80 pt-3 text-xs font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Model File Size:</span>
                    <span className="text-slate-200 font-bold">{size} MB</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Speedup Factor:</span>
                    <span className="text-emerald-400 font-bold">{spd}x Speedup</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Accuracy Retention:</span>
                    <span className={`${acc > 95 ? 'text-cyan-300' : 'text-amber-400'} font-bold`}>
                      {acc}% mAP
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Visual Pipeline Architecture Graph */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <Layers className="h-4 w-4 text-cyan-400" />
          Interactive Edge Inference Pipeline Architecture
        </h3>

        <div className="flex flex-col lg:flex-row items-center justify-between gap-3 p-4 bg-slate-950/80 rounded-xl border border-slate-800/80 overflow-x-auto text-xs font-mono">
          {/* Stage 1: Input Frame */}
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 min-w-[150px] text-center">
            <div className="text-[10px] text-slate-500">INPUT CAMERA</div>
            <div className="font-bold text-slate-200 mt-1">1080p RTSP Stream</div>
            <div className="text-[10px] text-cyan-400 mt-0.5">NV12 / YUV420</div>
          </div>

          <ArrowRight className="h-4 w-4 text-slate-600 shrink-0 hidden lg:block" />

          {/* Stage 2: Hardware Preprocessing */}
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 min-w-[170px] text-center">
            <div className="text-[10px] text-slate-500">HW PREPROCESSING</div>
            <div className="font-bold text-slate-200 mt-1">Letterbox & Scale</div>
            <div className="text-[10px] text-amber-400 mt-0.5">
              [{activeModel.inputResolution[0]}x{activeModel.inputResolution[1]}] {activePrecision}
            </div>
          </div>

          <ArrowRight className="h-4 w-4 text-slate-600 shrink-0 hidden lg:block" />

          {/* Stage 3: Neural Backbone & Head */}
          <div className="p-3 rounded-lg bg-cyan-950/40 border border-cyan-500/50 min-w-[200px] text-center">
            <div className="text-[10px] text-cyan-400">NPU ENGINE</div>
            <div className="font-bold text-white mt-1">{activeModel.name}</div>
            <div className="text-[10px] text-cyan-300 mt-0.5">
              {activeHardware.framework.split('/')[0]} · {estLatency} ms
            </div>
          </div>

          <ArrowRight className="h-4 w-4 text-slate-600 shrink-0 hidden lg:block" />

          {/* Stage 4: Postprocessing & NMS */}
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 min-w-[170px] text-center">
            <div className="text-[10px] text-slate-500">POSTPROCESSING</div>
            <div className="font-bold text-slate-200 mt-1">EfficientNMS Kernel</div>
            <div className="text-[10px] text-emerald-400 mt-0.5">IoU: 0.45 · Top-K: 100</div>
          </div>

          <ArrowRight className="h-4 w-4 text-slate-600 shrink-0 hidden lg:block" />

          {/* Stage 5: Industrial Trigger Action */}
          <div className="p-3 rounded-lg bg-slate-900 border border-slate-800 min-w-[150px] text-center">
            <div className="text-[10px] text-slate-500">OUTPUT ACTION</div>
            <div className="font-bold text-rose-300 mt-1">PLC / GPIO Relay</div>
            <div className="text-[10px] text-slate-400 mt-0.5">MQTT Telemetry</div>
          </div>
        </div>
      </div>

      {/* Production Deployment Snippet Generator */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
              <Code className="h-4 w-4 text-cyan-400" />
              Target Edge Runtime Code Generation (Python / C++)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Production-tested boilerplate to load the compiled engine on your physical edge node.
            </p>
          </div>

          {/* Framework Switcher */}
          <div className="flex items-center gap-1.5 bg-slate-800/80 p-1 rounded-lg border border-slate-700 text-xs">
            {(['tensorrt', 'openvino', 'hailo', 'tflite'] as const).map((fw) => (
              <button
                key={fw}
                onClick={() => setExportFramework(fw)}
                className={`px-2.5 py-1 rounded capitalize font-medium transition-colors ${
                  exportFramework === fw
                    ? 'bg-cyan-600 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                {fw}
              </button>
            ))}
          </div>
        </div>

        {/* Code Box */}
        <div className="relative rounded-xl border border-slate-800 bg-[#050811] p-4 font-mono text-xs text-slate-300 overflow-x-auto">
          <button
            onClick={copyCode}
            className="absolute top-3 right-3 flex items-center gap-1.5 rounded-lg bg-slate-800/90 border border-slate-700 px-3 py-1.5 text-xs text-slate-300 hover:text-white hover:bg-slate-700 transition-colors"
          >
            {copiedCode ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
            {copiedCode ? 'Copied!' : 'Copy Code'}
          </button>

          <pre className="text-slate-300 leading-relaxed font-mono">
            {getDeploymentSnippet()}
          </pre>
        </div>
      </div>
    </div>
  );
};
