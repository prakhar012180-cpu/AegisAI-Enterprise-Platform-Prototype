import React, { useState, useEffect } from 'react';
import { 
  Terminal, 
  Download, 
  Trash2, 
  Filter, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  FileSpreadsheet,
  Activity
} from 'lucide-react';

interface TelemetryEvent {
  id: string;
  timestamp: string;
  scenario: string;
  hardware: string;
  model: string;
  fps: number;
  latencyMs: number;
  status: 'PASS' | 'WARN' | 'DEFECT' | 'CRITICAL';
  defectType?: string;
  confidence: number;
  actionTaken: string;
  auditNotes?: string;
}

export const TelemetryView: React.FC = () => {
  const [events, setEvents] = useState<TelemetryEvent[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [filterStatus, setFilterStatus] = useState<'ALL' | 'DEFECT' | 'WARN' | 'PASS'>('ALL');

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/telemetry/events');
      const data = await res.json();
      if (data.success && data.events) {
        setEvents(data.events);
      }
    } catch (err) {
      console.error('Error fetching telemetry:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  const filteredEvents = events.filter((e) => {
    if (filterStatus === 'ALL') return true;
    return e.status === filterStatus;
  });

  const exportCsv = () => {
    const headers = ['ID', 'Timestamp', 'Scenario', 'Hardware', 'FPS', 'Latency_ms', 'Status', 'Defect', 'Confidence', 'Action_Taken'];
    const rows = filteredEvents.map((e) => [
      e.id,
      e.timestamp,
      `"${e.scenario}"`,
      `"${e.hardware}"`,
      e.fps,
      e.latencyMs,
      e.status,
      `"${e.defectType || 'None'}"`,
      e.confidence,
      `"${e.actionTaken}"`,
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `edge_vision_telemetry_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportJson = () => {
    const blob = new Blob([JSON.stringify(filteredEvents, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `edge_vision_telemetry_${Date.now()}.json`;
    link.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Header Card */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Terminal className="h-5 w-5 text-cyan-400" />
            Edge Telemetry & Quality Event Stream
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time optical inspection records, PLC triggers, and quality audit trails with sub-millisecond precision.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={fetchEvents}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors"
          >
            <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} />
            Refresh
          </button>
          <button
            onClick={exportCsv}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors"
          >
            <FileSpreadsheet className="h-3.5 w-3.5 text-emerald-400" />
            Export CSV
          </button>
          <button
            onClick={exportJson}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-semibold transition-colors"
          >
            <Download className="h-3.5 w-3.5" />
            Export JSON
          </button>
        </div>
      </div>

      {/* Filter Tabs (Interactive buttons) */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 bg-slate-900/80 p-1 rounded-lg border border-slate-800 text-xs">
          <button
            onClick={() => setFilterStatus('ALL')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              filterStatus === 'ALL'
                ? 'bg-cyan-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            All Events ({events.length})
          </button>
          <button
            onClick={() => setFilterStatus('DEFECT')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              filterStatus === 'DEFECT'
                ? 'bg-rose-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Defects Only
          </button>
          <button
            onClick={() => setFilterStatus('WARN')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              filterStatus === 'WARN'
                ? 'bg-amber-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Warnings
          </button>
          <button
            onClick={() => setFilterStatus('PASS')}
            className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
              filterStatus === 'PASS'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            Nominal Pass
          </button>
        </div>

        <span className="text-xs font-mono text-slate-400">
          Showing <strong>{filteredEvents.length}</strong> recorded inspection events
        </span>
      </div>

      {/* Events Table */}
      <div className="rounded-xl border border-slate-800 bg-slate-950/80 overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-900 border-b border-slate-800 text-[11px] text-slate-400 uppercase tracking-wider">
              <tr>
                <th className="py-3 px-4">Event ID</th>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Scenario</th>
                <th className="py-3 px-4">Hardware Target</th>
                <th className="py-3 px-4">Performance</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Observation / Defect</th>
                <th className="py-3 px-4">Action Taken</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredEvents.map((evt) => (
                <tr key={evt.id} className="hover:bg-slate-900/50 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-cyan-300">{evt.id}</td>
                  <td className="py-3.5 px-4 text-slate-400 text-[11px]">
                    {new Date(evt.timestamp).toLocaleTimeString()}
                  </td>
                  <td className="py-3.5 px-4 font-sans text-white font-medium">{evt.scenario}</td>
                  <td className="py-3.5 px-4 text-slate-300">{evt.hardware}</td>
                  <td className="py-3.5 px-4">
                    <span className="text-emerald-400 font-bold">{evt.fps} FPS</span>
                    <span className="text-slate-500 text-[10px] block">{evt.latencyMs}ms</span>
                  </td>
                  <td className="py-3.5 px-4">
                    {evt.status === 'DEFECT' ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-rose-950/80 text-rose-300 border border-rose-700/60">
                        <span className="h-1.5 w-1.5 rounded-full bg-rose-500 animate-pulse" />
                        DEFECT
                      </span>
                    ) : evt.status === 'WARN' ? (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-950/80 text-amber-300 border border-amber-700/60">
                        WARN
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950/80 text-emerald-300 border border-emerald-700/60">
                        PASS
                      </span>
                    )}
                  </td>
                  <td className="py-3.5 px-4 font-sans text-slate-200">
                    <div>{evt.defectType || 'All nominal'}</div>
                    {evt.auditNotes && (
                      <div className="text-[10px] text-slate-400 line-clamp-1 italic mt-0.5 font-sans">
                        {evt.auditNotes}
                      </div>
                    )}
                  </td>
                  <td className="py-3.5 px-4 text-cyan-400 font-sans text-xs">
                    {evt.actionTaken}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
