import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  Camera, 
  Upload, 
  Layers, 
  Crosshair, 
  Sliders, 
  Flame, 
  Sparkles, 
  AlertTriangle, 
  CheckCircle2, 
  Download, 
  RefreshCw, 
  Video, 
  VideoOff, 
  Cpu, 
  Maximize2,
  ChevronRight,
  Eye,
  SlidersHorizontal,
  Info
} from 'lucide-react';
import { 
  InspectionScenario, 
  HardwareProfile, 
  VisionModelSpec, 
  PrecisionType, 
  DetectionObject, 
  RegionOfInterest,
  AuditReport
} from '../types/edge';
import { INSPECTION_SCENARIOS } from '../data/sampleScenarios';
import { HARDWARE_PROFILES, VISION_MODELS } from '../data/hardwareProfiles';
import { drawInspectionCanvas, RenderOptions } from '../utils/canvasRenderer';

interface VisionInspectorProps {
  activeHardware: HardwareProfile;
  setActiveHardware: (hw: HardwareProfile) => void;
  activeModel: VisionModelSpec;
  setActiveModel: (m: VisionModelSpec) => void;
  activePrecision: PrecisionType;
  setActivePrecision: (p: PrecisionType) => void;
  onTriggerAudit: (frameBase64: string, scenario: InspectionScenario, detectedObjects: DetectionObject[]) => void;
  isAuditing: boolean;
  onLogTelemetryEvent: (event: any) => void;
}

export const VisionInspector: React.FC<VisionInspectorProps> = ({
  activeHardware,
  setActiveHardware,
  activeModel,
  setActiveModel,
  activePrecision,
  setActivePrecision,
  onTriggerAudit,
  isAuditing,
  onLogTelemetryEvent,
}) => {
  // Active Scenario
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>('pcb-aoi');
  const scenario = INSPECTION_SCENARIOS.find((s) => s.id === selectedScenarioId) || INSPECTION_SCENARIOS[0];

  // Active ROIs for current scenario
  const [rois, setRois] = useState<RegionOfInterest[]>(scenario.rois);

  useEffect(() => {
    setRois(scenario.rois);
  }, [selectedScenarioId]);

  // Video and Stream state
  const [streamSource, setStreamSource] = useState<'synthetic' | 'webcam' | 'upload'>('synthetic');
  const [webcamActive, setWebcamActive] = useState<boolean>(false);
  const [webcamError, setWebcamError] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);

  // User uploaded image
  const [userImageElement, setUserImageElement] = useState<HTMLImageElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  // Canvas
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [frameTick, setFrameTick] = useState<number>(0);

  // Inspector Render Options
  const [renderOptions, setRenderOptions] = useState<RenderOptions>({
    showBBoxes: true,
    showLabels: true,
    showHeatmap: true,
    showRois: true,
    showHudReticle: true,
    confidenceThreshold: 0.60,
  });

  // Dynamic Latency & FPS calculation
  const baseLat = scenario.baseLatencyMs;
  const hwMult = activeHardware.baseLatencyMultiplier;
  const speedMult = activeModel.speedMultiplier[activePrecision] || 1.0;
  const calculatedLatency = Math.max(1.8, (baseLat * hwMult) / speedMult);
  const calculatedFps = Math.min(240, Math.round(1000 / calculatedLatency));

  // Objects currently in view (from scenario or generated)
  const [detectedObjects, setDetectedObjects] = useState<DetectionObject[]>(scenario.objects);

  useEffect(() => {
    // When scenario changes, update default objects
    setDetectedObjects(scenario.objects);
  }, [scenario]);

  // Toggle Webcam
  const toggleWebcam = async () => {
    if (webcamActive) {
      if (mediaStreamRef.current) {
        mediaStreamRef.current.getTracks().forEach((track) => track.stop());
        mediaStreamRef.current = null;
      }
      setWebcamActive(false);
      setStreamSource('synthetic');
    } else {
      try {
        setWebcamError(null);
        const stream = await navigator.mediaDevices.getUserMedia({
          video: {
            width: { ideal: 1280 },
            height: { ideal: 720 },
          },
        });
        mediaStreamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          videoRef.current.play();
        }
        setWebcamActive(true);
        setStreamSource('webcam');
      } catch (err: any) {
        console.error('Camera access error:', err);
        setWebcamError(err.message || 'Camera permission denied or camera device unavailable.');
        setStreamSource('synthetic');
      }
    }
  };

  // Upload image handler
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          setUserImageElement(img);
          setStreamSource('upload');
          // Synthesize detections on user uploaded frame
          setDetectedObjects([
            {
              id: 'user-obj-1',
              label: 'Target Surface Region #1',
              score: 0.94,
              bbox: [0.2, 0.2, 0.6, 0.6],
              color: '#38bdf8',
              category: 'component',
            },
            {
              id: 'user-obj-2',
              label: 'Anomaly Flagged by Model',
              score: 0.88,
              bbox: [0.38, 0.38, 0.24, 0.24],
              color: '#ef4444',
              category: 'defect',
              isDefect: true,
              defectName: 'Unclassified Surface Flaw',
              defectSeverity: 'HIGH',
            },
          ]);
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    }
  };

  // Canvas animation render loop
  useEffect(() => {
    let animId: number;
    let tick = 0;

    const render = () => {
      tick++;
      setFrameTick(tick);

      const canvas = canvasRef.current;
      if (canvas) {
        const ctx = canvas.getContext('2d');
        if (ctx) {
          drawInspectionCanvas(
            ctx,
            canvas.width,
            canvas.height,
            scenario.id,
            streamSource === 'upload' ? userImageElement : null,
            streamSource === 'webcam' ? videoRef.current : null,
            detectedObjects,
            rois,
            renderOptions,
            tick
          );
        }
      }
      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);
    return () => cancelAnimationFrame(animId);
  }, [scenario.id, streamSource, userImageElement, detectedObjects, rois, renderOptions]);

  // Capture Snapshot and Trigger Audit
  const handleCaptureAndAudit = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/jpeg', 0.92);
    onTriggerAudit(dataUrl, scenario, detectedObjects);
  }, [scenario, detectedObjects, onTriggerAudit]);

  // Download snapshot locally
  const handleDownloadSnapshot = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const link = document.createElement('a');
    link.download = `edge-vision-frame-${scenario.id}-${Date.now()}.jpg`;
    link.href = canvas.toDataURL('image/jpeg', 0.95);
    link.click();
  };

  // Toggle an ROI
  const toggleRoi = (id: string) => {
    setRois((prev) =>
      prev.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r))
    );
  };

  return (
    <div className="space-y-6">
      {/* Hidden Video for Webcam */}
      <video ref={videoRef} playsInline muted className="hidden" />
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleImageUpload}
        accept="image/*"
        className="hidden"
      />

      {/* Top Scenario & Source Switcher Bar */}
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-4">
        {/* Scenario Selection */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-semibold text-slate-400">INSPECTION TESTBENCH:</span>
          <div className="flex flex-wrap gap-1.5">
            {INSPECTION_SCENARIOS.map((sc) => (
              <button
                key={sc.id}
                onClick={() => {
                  setSelectedScenarioId(sc.id);
                  if (streamSource === 'upload') setStreamSource('synthetic');
                }}
                className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors border ${
                  selectedScenarioId === sc.id
                    ? 'bg-cyan-500/20 text-cyan-200 border-cyan-500/50 shadow-sm'
                    : 'bg-slate-800/80 text-slate-300 border-slate-700/60 hover:bg-slate-800 hover:text-white'
                }`}
              >
                {sc.title.split(' ')[0]} {sc.title.split(' ')[1]}
              </button>
            ))}
          </div>
        </div>

        {/* Video Input Source Switcher */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">SOURCE:</span>
          <div className="flex items-center rounded-lg bg-slate-800/80 p-0.5 border border-slate-700">
            <button
              onClick={() => {
                if (webcamActive) toggleWebcam();
                setStreamSource('synthetic');
              }}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                streamSource === 'synthetic'
                  ? 'bg-cyan-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Simulated Feed
            </button>
            <button
              onClick={toggleWebcam}
              className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                streamSource === 'webcam'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {webcamActive ? <Video className="h-3 w-3" /> : <VideoOff className="h-3 w-3" />}
              {webcamActive ? 'Live Camera' : 'Connect Camera'}
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className={`flex items-center gap-1 px-2.5 py-1 text-xs font-medium rounded-md transition-colors ${
                streamSource === 'upload'
                  ? 'bg-indigo-600 text-white shadow-sm'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Upload className="h-3 w-3" />
              Upload Image
            </button>
          </div>
        </div>
      </div>

      {webcamError && (
        <div className="flex items-center gap-2 rounded-lg border border-amber-800/50 bg-amber-950/30 p-3 text-xs text-amber-300">
          <AlertTriangle className="h-4 w-4 shrink-0 text-amber-400" />
          <span>{webcamError} Switched back to synthetic industrial inspection feed.</span>
        </div>
      )}

      {/* Main Viewport Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Canvas Viewport & HUD Overlay Controls (8 cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="relative overflow-hidden rounded-xl border border-slate-800 bg-[#060a12] shadow-2xl">
            {/* Real-time HUD Ticker Overlay */}
            <div className="absolute top-3 left-3 z-20 flex flex-wrap items-center gap-2 font-mono text-[11px] pointer-events-none">
              <span className="bg-slate-900/90 text-cyan-300 px-2.5 py-1 rounded border border-cyan-500/30 backdrop-blur-md">
                FPS: <strong className="text-white">{calculatedFps}</strong>
              </span>
              <span className="bg-slate-900/90 text-emerald-300 px-2.5 py-1 rounded border border-emerald-500/30 backdrop-blur-md">
                LATENCY: <strong className="text-white">{calculatedLatency.toFixed(1)}ms</strong>
              </span>
              <span className="bg-slate-900/90 text-slate-300 px-2.5 py-1 rounded border border-slate-700 backdrop-blur-md">
                {activeHardware.name.split(' ')[0]} · {activePrecision}
              </span>
              {scenario.defectPresent && (
                <span className="bg-rose-950/90 text-rose-300 px-2.5 py-1 rounded border border-rose-500/40 backdrop-blur-md flex items-center gap-1 font-semibold">
                  <span className="h-1.5 w-1.5 rounded-full bg-rose-500 animate-ping"></span>
                  DEFECT DETECTED
                </span>
              )}
            </div>

            {/* Quick Actions at Top Right of Canvas */}
            <div className="absolute top-3 right-3 z-20 flex items-center gap-1.5">
              <button
                onClick={handleDownloadSnapshot}
                title="Download Snapshot Frame"
                className="flex h-8 w-8 items-center justify-center rounded-lg bg-slate-900/80 text-slate-300 border border-slate-700/80 hover:bg-slate-800 hover:text-white backdrop-blur-md transition-colors"
              >
                <Download className="h-4 w-4" />
              </button>
              <button
                onClick={handleCaptureAndAudit}
                disabled={isAuditing}
                className="flex items-center gap-1.5 rounded-lg bg-gradient-to-r from-indigo-600 to-cyan-600 px-3 py-1.5 text-xs font-semibold text-white shadow-md hover:from-indigo-500 hover:to-cyan-500 transition-all backdrop-blur-md disabled:opacity-50"
              >
                <Sparkles className={`h-3.5 w-3.5 text-cyan-200 ${isAuditing ? 'animate-spin' : ''}`} />
                {isAuditing ? 'Auditing...' : 'Audit Frame'}
              </button>
            </div>

            {/* Canvas Element */}
            <div className="relative aspect-video w-full bg-[#050810] flex items-center justify-center">
              <canvas
                ref={canvasRef}
                width={960}
                height={540}
                className="h-full w-full object-contain"
              />
              <div className="scanline-overlay absolute inset-0 pointer-events-none opacity-40" />
            </div>

            {/* Bottom Viewport Status Strip */}
            <div className="flex items-center justify-between border-t border-slate-800/80 bg-slate-950/80 px-4 py-2.5 text-xs text-slate-400 font-mono">
              <div className="flex items-center gap-3">
                <span className="text-slate-300">{scenario.title}</span>
                <span className="text-slate-600">·</span>
                <span className="text-cyan-400">{scenario.industry}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-slate-500">STD:</span>
                <span className="text-slate-300">{scenario.standardReference.split(' ')[0]}</span>
              </div>
            </div>
          </div>

          {/* Viewport Display Controls Toolbar */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <SlidersHorizontal className="h-3.5 w-3.5 text-cyan-400" />
                HUD & Display Overlays
              </span>
              <span className="text-[11px] font-mono text-slate-400">
                Confidence Threshold: <strong className="text-cyan-400">{(renderOptions.confidenceThreshold * 100).toFixed(0)}%</strong>
              </span>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={() => setRenderOptions((p) => ({ ...p, showBBoxes: !p.showBBoxes }))}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                    renderOptions.showBBoxes
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                      : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:text-slate-200'
                  }`}
                >
                  Bounding Boxes
                </button>
                <button
                  onClick={() => setRenderOptions((p) => ({ ...p, showLabels: !p.showLabels }))}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                    renderOptions.showLabels
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                      : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:text-slate-200'
                  }`}
                >
                  Class Labels
                </button>
                <button
                  onClick={() => setRenderOptions((p) => ({ ...p, showHeatmap: !p.showHeatmap }))}
                  className={`flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                    renderOptions.showHeatmap
                      ? 'bg-rose-500/20 text-rose-300 border-rose-500/40'
                      : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:text-slate-200'
                  }`}
                >
                  <Flame className="h-3 w-3" />
                  Anomaly Heatmap
                </button>
                <button
                  onClick={() => setRenderOptions((p) => ({ ...p, showRois: !p.showRois }))}
                  className={`px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                    renderOptions.showRois
                      ? 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40'
                      : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:text-slate-200'
                  }`}
                >
                  Inspection ROIs
                </button>
                <button
                  onClick={() => setRenderOptions((p) => ({ ...p, showHudReticle: !p.showHudReticle }))}
                  className={`flex items-center gap-1 px-3 py-1.5 text-xs font-medium rounded-lg border transition-colors ${
                    renderOptions.showHudReticle
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                      : 'bg-slate-800/60 text-slate-400 border-slate-700/60 hover:text-slate-200'
                  }`}
                >
                  <Crosshair className="h-3 w-3" />
                  HUD Reticle
                </button>
              </div>

              {/* Threshold Slider */}
              <div className="flex items-center gap-2 min-w-[160px]">
                <input
                  type="range"
                  min="0.2"
                  max="0.95"
                  step="0.05"
                  value={renderOptions.confidenceThreshold}
                  onChange={(e) =>
                    setRenderOptions((p) => ({
                      ...p,
                      confidenceThreshold: parseFloat(e.target.value),
                    }))
                  }
                  className="w-full accent-cyan-500 bg-slate-800 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Active Inferences, ROI Management, Hardware Quick Switch (4 cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Active Detections & Defect Triage Box */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Layers className="h-3.5 w-3.5 text-cyan-400" />
                Active Detections ({detectedObjects.length})
              </h3>
              <span className="text-[11px] font-mono text-emerald-400">
                NMS: 0.45
              </span>
            </div>

            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {detectedObjects.map((obj) => (
                <div
                  key={obj.id}
                  className={`flex items-center justify-between p-2.5 rounded-lg border text-xs transition-colors ${
                    obj.isDefect
                      ? 'bg-rose-950/40 border-rose-800/60 text-rose-200'
                      : 'bg-slate-800/50 border-slate-700/50 text-slate-300'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="h-2.5 w-2.5 rounded-sm shrink-0"
                      style={{ backgroundColor: obj.color }}
                    />
                    <div>
                      <div className="font-medium text-white">{obj.label}</div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        Class: {obj.category} · Score: {(obj.score * 100).toFixed(0)}%
                      </div>
                    </div>
                  </div>

                  {obj.isDefect && (
                    <span className="text-[10px] font-mono font-bold text-rose-400 bg-rose-900/40 px-1.5 py-0.5 rounded border border-rose-700/50">
                      FLAGGED
                    </span>
                  )}
                </div>
              ))}
            </div>

            {/* Quick Action Button for Defect */}
            {scenario.defectPresent && (
              <div className="rounded-lg border border-rose-800/50 bg-rose-950/30 p-3 space-y-2">
                <div className="flex items-center gap-2 text-xs font-semibold text-rose-300">
                  <AlertTriangle className="h-4 w-4 text-rose-400 shrink-0" />
                  <span>Defect Identified: {scenario.defectType}</span>
                </div>
                <p className="text-[11px] text-rose-200/80 leading-relaxed">
                  Ref: {scenario.standardReference}
                </p>
                <button
                  onClick={handleCaptureAndAudit}
                  disabled={isAuditing}
                  className="w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold transition-colors shadow-sm disabled:opacity-50"
                >
                  <Sparkles className="h-3.5 w-3.5" />
                  Run Gemini Root Cause Audit
                </button>
              </div>
            )}
          </div>

          {/* Region of Interest (ROI) Manager */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Crosshair className="h-3.5 w-3.5 text-indigo-400" />
                Inspection ROIs ({rois.length})
              </h3>
            </div>

            <div className="space-y-2">
              {rois.map((roi) => (
                <div
                  key={roi.id}
                  className="flex items-center justify-between p-2.5 rounded-lg bg-slate-800/50 border border-slate-700/50 text-xs"
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ backgroundColor: roi.color }}
                    />
                    <span className="font-medium text-slate-200">{roi.name}</span>
                  </div>

                  <button
                    onClick={() => toggleRoi(roi.id)}
                    className={`px-2 py-1 rounded text-[10px] font-mono font-medium transition-colors ${
                      roi.enabled
                        ? 'bg-indigo-600/30 text-indigo-300 border border-indigo-500/40'
                        : 'bg-slate-700 text-slate-400'
                    }`}
                  >
                    {roi.enabled ? 'ACTIVE' : 'MUTED'}
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Edge Target Quick Selector */}
          <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
                <Cpu className="h-3.5 w-3.5 text-cyan-400" />
                Edge Hardware Target
              </h3>
            </div>

            <div className="space-y-1.5">
              {HARDWARE_PROFILES.map((hw) => (
                <button
                  key={hw.id}
                  onClick={() => {
                    setActiveHardware(hw);
                    if (!hw.supportedPrecisions.includes(activePrecision)) {
                      setActivePrecision(hw.defaultPrecision);
                    }
                  }}
                  className={`w-full flex items-center justify-between p-2 rounded-lg border text-left text-xs transition-colors ${
                    activeHardware.id === hw.id
                      ? 'bg-cyan-500/15 border-cyan-500/50 text-cyan-200'
                      : 'bg-slate-800/40 border-slate-700/40 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  <div>
                    <div className="font-semibold text-white">{hw.name}</div>
                    <div className="text-[10px] text-slate-400 font-mono">
                      {hw.tops} TOPS · {hw.powerTdpWatt}W TDP
                    </div>
                  </div>
                  <span className="text-[10px] font-mono text-cyan-300">
                    {hw.framework.split('/')[0]}
                  </span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
