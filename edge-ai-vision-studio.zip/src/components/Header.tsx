import React from 'react';
import { 
  Eye, 
  Cpu, 
  Sliders, 
  Zap, 
  Terminal, 
  Sparkles, 
  Activity, 
  Camera, 
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { HardwareProfile, PrecisionType } from '../types/edge';

interface HeaderProps {
  activeTab: 'inspector' | 'profiler' | 'quantization' | 'automation' | 'telemetry';
  setActiveTab: (tab: 'inspector' | 'profiler' | 'quantization' | 'automation' | 'telemetry') => void;
  activeHardware: HardwareProfile;
  activePrecision: PrecisionType;
  fps: number;
  latencyMs: number;
  hasDefect: boolean;
  onOpenAudit: () => void;
  isAuditing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  activeHardware,
  activePrecision,
  fps,
  latencyMs,
  hasDefect,
  onOpenAudit,
  isAuditing,
}) => {
  return (
    <header className="sticky top-0 z-50 border-b border-slate-800 bg-[#070b13]/90 backdrop-blur-md">
      {/* Top Cockpit Telemetry Banner */}
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-2 text-xs border-b border-slate-850/60 font-mono text-slate-400">
        <div className="flex items-center gap-3">
          <span className="flex items-center gap-1.5 text-cyan-400 font-semibold tracking-wider">
            <span className="relative flex h-2 w-2">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-cyan-400 opacity-75"></span>
              <span className="relative inline-flex h-2 w-2 rounded-full bg-cyan-500"></span>
            </span>
            EDGE-NODE-01
          </span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-300">HW: {activeHardware.name}</span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">PRECISION: <span className="text-cyan-300">{activePrecision}</span></span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">INFERENCE: <span className="text-emerald-400 font-bold">{latencyMs.toFixed(1)}ms</span></span>
          <span className="text-slate-600">|</span>
          <span className="text-slate-400">THROUGHPUT: <span className="text-emerald-400 font-bold">{fps.toFixed(0)} FPS</span></span>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <span className="text-slate-500">LINE STATUS:</span>
            {hasDefect ? (
              <span className="flex items-center gap-1 text-rose-400 font-bold">
                <span className="h-1.5 w-1.5 rounded-full bg-rose-500 animate-pulse"></span>
                DEFECT FLAGGED
              </span>
            ) : (
              <span className="flex items-center gap-1 text-emerald-400 font-medium">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                NOMINAL / PASS
              </span>
            )}
          </div>
          <span className="text-slate-700">|</span>
          <span className="text-indigo-300 flex items-center gap-1">
            <Sparkles className="h-3.5 w-3.5 text-indigo-400" />
            Gemini Multimodal Active
          </span>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500/20 to-blue-600/30 border border-cyan-500/40 text-cyan-400 shadow-lg shadow-cyan-500/10">
            <Eye className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base font-bold tracking-tight text-white">
                Edge AI Vision Studio
              </h1>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                v2.6-PRO
              </span>
            </div>
            <p className="text-xs text-slate-400">
              Real-time Edge Inspection · Hardware Profiler · Gemini Vision Audit
            </p>
          </div>
        </div>

        {/* Navigation Tabs (Functional interactive buttons per anti-slop guidelines) */}
        <nav className="flex items-center gap-1 bg-slate-900/80 p-1 rounded-lg border border-slate-800 text-xs font-medium">
          <button
            onClick={() => setActiveTab('inspector')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-all ${
              activeTab === 'inspector'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Camera className="h-3.5 w-3.5" />
            Vision Inspector
          </button>

          <button
            onClick={() => setActiveTab('profiler')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-all ${
              activeTab === 'profiler'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Cpu className="h-3.5 w-3.5" />
            Hardware Profiler
          </button>

          <button
            onClick={() => setActiveTab('quantization')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-all ${
              activeTab === 'quantization'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Sliders className="h-3.5 w-3.5" />
            Quantization & Pipeline
          </button>

          <button
            onClick={() => setActiveTab('automation')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-all ${
              activeTab === 'automation'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Zap className="h-3.5 w-3.5" />
            I/O & Automation
          </button>

          <button
            onClick={() => setActiveTab('telemetry')}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-md transition-all ${
              activeTab === 'telemetry'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Terminal className="h-3.5 w-3.5" />
            Telemetry Logs
          </button>
        </nav>

        {/* Gemini Vision Audit CTA */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenAudit}
            disabled={isAuditing}
            className="flex items-center gap-2 rounded-lg bg-gradient-to-r from-indigo-600 to-cyan-600 px-3.5 py-2 text-xs font-semibold text-white shadow-md shadow-indigo-600/20 transition-all hover:from-indigo-500 hover:to-cyan-500 hover:shadow-indigo-500/30 active:scale-95 disabled:opacity-50"
          >
            <Sparkles className={`h-3.5 w-3.5 text-cyan-200 ${isAuditing ? 'animate-spin' : ''}`} />
            {isAuditing ? 'Auditing Frame...' : 'Gemini Deep Vision Audit'}
          </button>
        </div>
      </div>
    </header>
  );
};
