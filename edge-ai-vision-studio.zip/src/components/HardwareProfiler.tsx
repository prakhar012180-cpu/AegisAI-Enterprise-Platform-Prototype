import React, { useState } from 'react';
import { 
  Cpu, 
  Flame, 
  Zap, 
  DollarSign, 
  TrendingUp, 
  Check, 
  AlertTriangle, 
  Leaf, 
  Thermometer, 
  Layers,
  BarChart3,
  HardDrive
} from 'lucide-react';
import { HardwareProfile, VisionModelSpec, PrecisionType } from '../types/edge';
import { HARDWARE_PROFILES } from '../data/hardwareProfiles';

interface HardwareProfilerProps {
  activeHardware: HardwareProfile;
  setActiveHardware: (hw: HardwareProfile) => void;
  activeModel: VisionModelSpec;
  activePrecision: PrecisionType;
}

export const HardwareProfiler: React.FC<HardwareProfilerProps> = ({
  activeHardware,
  setActiveHardware,
  activeModel,
  activePrecision,
}) => {
  // Thermal Simulation State
  const [ambientTempC, setAmbientTempC] = useState<number>(35); // Ambient cabinet temperature
  const [dutyCyclePct, setDutyCyclePct] = useState<number>(85); // % continuous inference
  const [coolingMode, setCoolingMode] = useState<'passive' | 'fan' | 'industrial'>('fan');

  // Thermal Resistance Theta JA (°C / W) based on cooling
  const thermalResistance = coolingMode === 'passive' ? 3.8 : coolingMode === 'fan' ? 1.8 : 0.9;
  
  // Power load in Watts
  const activePowerW = activeHardware.minWatt + (activeHardware.powerTdpWatt - activeHardware.minWatt) * (dutyCyclePct / 100);
  
  // Calculated Junction Temperature (°C)
  const junctionTempC = Math.round(ambientTempC + activePowerW * thermalResistance);

  // Throttling Logic
  const throttleThresholdC = 82;
  const isThrottling = junctionTempC > throttleThresholdC;
  const throttleDelta = Math.max(0, junctionTempC - throttleThresholdC);
  const throttlingLossPct = Math.min(65, Math.round(throttleDelta * 3.5)); // Drop in clock speed
  
  // Adjusted Latency & FPS
  const baseLat = 8.5 * activeHardware.baseLatencyMultiplier;
  const normalFps = Math.round(1000 / (baseLat / (activeModel.speedMultiplier[activePrecision] || 1.0)));
  const effectiveFps = isThrottling 
    ? Math.round(normalFps * (1 - throttlingLossPct / 100))
    : normalFps;

  // TCO & Energy calculations (24/7/365 deployment)
  const annualHours = 8760;
  const kwhAnnual = ((activePowerW * annualHours) / 1000).toFixed(1);
  const electricityCostUsd = ((parseFloat(kwhAnnual) * 0.16)).toFixed(2); // $0.16 / kWh industrial rate
  const carbonFootprintKg = ((parseFloat(kwhAnnual) * 0.385)).toFixed(1); // 385g CO2 / kWh avg grid
  const costPerMillionInferences = (
    ((activePowerW / 1000) * (1000000 / (effectiveFps * 3600)) * 0.16) +
    (activeHardware.costUsd / (effectiveFps * 3600 * 24 * 365 * 3)) * 1000000 // 3-year hardware amortization
  ).toFixed(3);

  return (
    <div className="space-y-8">
      {/* Overview Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 rounded-xl border border-slate-800 bg-slate-900/60 p-6">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Cpu className="h-5 w-5 text-cyan-400" />
            Edge Hardware Profiler & Benchmark Matrix
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Evaluate silicon architectures, compute density (TOPS/W), thermal cabinet stability, and total deployment cost.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400">ACTIVE DEVICE:</span>
          <span className="font-mono text-xs font-bold text-cyan-300 bg-cyan-950/60 px-3 py-1.5 rounded-lg border border-cyan-500/40">
            {activeHardware.name}
          </span>
        </div>
      </div>

      {/* Hardware Comparison Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {HARDWARE_PROFILES.map((hw) => {
          const isSelected = activeHardware.id === hw.id;
          const topsPerWatt = (hw.tops / hw.powerTdpWatt).toFixed(1);
          const estFps = Math.round(1000 / (8.5 * hw.baseLatencyMultiplier));

          return (
            <div
              key={hw.id}
              onClick={() => setActiveHardware(hw)}
              className={`cursor-pointer rounded-xl border p-5 transition-all relative overflow-hidden ${
                isSelected
                  ? 'bg-slate-900 border-cyan-500/80 shadow-lg shadow-cyan-500/10'
                  : 'bg-slate-900/40 border-slate-800 hover:border-slate-700 hover:bg-slate-900/70'
              }`}
            >
              {isSelected && (
                <div className="absolute top-0 right-0 bg-cyan-500 text-[#090d16] text-[10px] font-bold font-mono px-2.5 py-0.5 rounded-bl">
                  BENCHMARK FOCUS
                </div>
              )}

              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-mono font-medium text-slate-400">{hw.vendor}</span>
                <span className="text-xs font-mono font-semibold text-emerald-400">${hw.costUsd} USD</span>
              </div>

              <h3 className="text-sm font-bold text-white mb-1">{hw.name}</h3>
              <p className="text-xs text-slate-400 line-clamp-1 mb-4">{hw.chipset}</p>

              {/* Hardware Spec Metrics */}
              <div className="grid grid-cols-2 gap-2 text-xs font-mono border-y border-slate-800/80 py-3 mb-3">
                <div>
                  <div className="text-[10px] text-slate-500">PEAK COMPUTE</div>
                  <div className="text-cyan-300 font-bold">{hw.tops} TOPS</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500">TDP POWER</div>
                  <div className="text-amber-300 font-bold">{hw.powerTdpWatt} Watts</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500">EFFICIENCY</div>
                  <div className="text-emerald-300 font-bold">{topsPerWatt} TOPS/W</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-500">THROUGHPUT</div>
                  <div className="text-white font-bold">{estFps} FPS</div>
                </div>
              </div>

              <div className="text-[11px] text-slate-400 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Runtime:</span>
                  <span className="font-mono text-slate-300">{hw.framework.split('/')[0]}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-slate-500">Memory:</span>
                  <span className="font-mono text-slate-300">{(hw.memoryMb / 1024).toFixed(0)} GB LPDDR</span>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-800/60 text-[11px] text-slate-400 italic">
                Best for: {hw.idealFor}
              </div>
            </div>
          );
        })}
      </div>

      {/* Interactive Thermal Throttling Simulator */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Thermometer className="h-5 w-5 text-amber-400" />
              Industrial Cabinet Thermal Throttling Simulator
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Simulate junction die temperatures under harsh factory temperatures (IP67 sealed NEMA enclosures).
            </p>
          </div>

          <div className="flex items-center gap-2 font-mono text-xs">
            <span className="text-slate-400">STATUS:</span>
            {isThrottling ? (
              <span className="flex items-center gap-1.5 text-rose-400 font-bold bg-rose-950/60 px-2.5 py-1 rounded border border-rose-600/50">
                <Flame className="h-3.5 w-3.5 animate-bounce" />
                THERMAL THROTTLING (-{throttlingLossPct}%)
              </span>
            ) : (
              <span className="flex items-center gap-1.5 text-emerald-400 font-bold bg-emerald-950/60 px-2.5 py-1 rounded border border-emerald-600/50">
                <Check className="h-3.5 w-3.5" />
                THERMAL STABLE
              </span>
            )}
          </div>
        </div>

        {/* Sliders and Controls */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Ambient Temp Slider */}
          <div className="space-y-2 rounded-lg bg-slate-800/40 p-4 border border-slate-700/50">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Ambient Enclosure Temp</span>
              <span className="font-mono font-bold text-amber-400">{ambientTempC}°C</span>
            </div>
            <input
              type="range"
              min="15"
              max="70"
              value={ambientTempC}
              onChange={(e) => setAmbientTempC(parseInt(e.target.value))}
              className="w-full accent-amber-500 bg-slate-700 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>15°C (AC Room)</span>
              <span>45°C (Factory)</span>
              <span>70°C (Furnace)</span>
            </div>
          </div>

          {/* Duty Cycle Load */}
          <div className="space-y-2 rounded-lg bg-slate-800/40 p-4 border border-slate-700/50">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-medium">Inference Duty Cycle</span>
              <span className="font-mono font-bold text-cyan-400">{dutyCyclePct}% Load</span>
            </div>
            <input
              type="range"
              min="10"
              max="100"
              value={dutyCyclePct}
              onChange={(e) => setDutyCyclePct(parseInt(e.target.value))}
              className="w-full accent-cyan-500 bg-slate-700 rounded cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>10% (Triggered)</span>
              <span>50% (Intermittent)</span>
              <span>100% (24/7 Full Stream)</span>
            </div>
          </div>

          {/* Cooling Solution */}
          <div className="space-y-2 rounded-lg bg-slate-800/40 p-4 border border-slate-700/50">
            <span className="text-xs text-slate-300 font-medium block">Thermal Dissipation Sink</span>
            <div className="grid grid-cols-3 gap-1.5 pt-1">
              <button
                onClick={() => setCoolingMode('passive')}
                className={`py-1.5 px-2 rounded text-[11px] font-medium border transition-colors ${
                  coolingMode === 'passive'
                    ? 'bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold'
                    : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-white'
                }`}
              >
                Passive Heat
              </button>
              <button
                onClick={() => setCoolingMode('fan')}
                className={`py-1.5 px-2 rounded text-[11px] font-medium border transition-colors ${
                  coolingMode === 'fan'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold'
                    : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-white'
                }`}
              >
                Active Fan
              </button>
              <button
                onClick={() => setCoolingMode('industrial')}
                className={`py-1.5 px-2 rounded text-[11px] font-medium border transition-colors ${
                  coolingMode === 'industrial'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-bold'
                    : 'bg-slate-900 text-slate-400 border-slate-700 hover:text-white'
                }`}
              >
                Vapor Chamber
              </button>
            </div>
            <div className="text-[10px] text-slate-500 font-mono">
              θja: {thermalResistance}°C/W
            </div>
          </div>
        </div>

        {/* Thermal Result Readout Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2">
          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-4">
            <div className="text-[10px] font-mono text-slate-500">JUNCTION DIE TEMP</div>
            <div className={`text-2xl font-bold font-mono mt-1 ${
              junctionTempC > 80 ? 'text-rose-400' : junctionTempC > 65 ? 'text-amber-400' : 'text-emerald-400'
            }`}>
              {junctionTempC}°C
            </div>
            <div className="text-[10px] text-slate-500 mt-1 font-mono">Limit: 85°C Max</div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-4">
            <div className="text-[10px] font-mono text-slate-500">ACTIVE POWER DRAW</div>
            <div className="text-2xl font-bold font-mono text-amber-300 mt-1">
              {activePowerW.toFixed(1)} W
            </div>
            <div className="text-[10px] text-slate-500 mt-1 font-mono">TDP: {activeHardware.powerTdpWatt}W</div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-4">
            <div className="text-[10px] font-mono text-slate-500">EFFECTIVE FPS</div>
            <div className="text-2xl font-bold font-mono text-cyan-300 mt-1">
              {effectiveFps} FPS
            </div>
            <div className="text-[10px] text-slate-500 mt-1 font-mono">
              {isThrottling ? `Throttled from ${normalFps} FPS` : 'Peak performance'}
            </div>
          </div>

          <div className="rounded-xl border border-slate-800 bg-slate-950/80 p-4">
            <div className="text-[10px] font-mono text-slate-500">THROTTLING RISK</div>
            <div className="text-2xl font-bold font-mono text-white mt-1">
              {isThrottling ? `${throttlingLossPct}% Loss` : '0% Nominal'}
            </div>
            <div className="text-[10px] text-slate-500 mt-1 font-mono">Clock governor active</div>
          </div>
        </div>
      </div>

      {/* Deployment TCO & Sustainability Metrics */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-4">
        <h3 className="text-base font-bold text-white flex items-center gap-2">
          <DollarSign className="h-5 w-5 text-emerald-400" />
          Production TCO & Sustainability Metrics (24/7/365 Continuous Line)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="rounded-lg bg-slate-800/40 border border-slate-700/50 p-4 font-mono">
            <span className="text-[10px] text-slate-400">COST PER 1M INFERENCES</span>
            <div className="text-xl font-bold text-emerald-400 mt-1">
              ${costPerMillionInferences}
            </div>
            <span className="text-[10px] text-slate-500">Includes power + 3yr hardware</span>
          </div>

          <div className="rounded-lg bg-slate-800/40 border border-slate-700/50 p-4 font-mono">
            <span className="text-[10px] text-slate-400">ANNUAL ELECTRICITY BILL</span>
            <div className="text-xl font-bold text-amber-300 mt-1">
              ${electricityCostUsd} / yr
            </div>
            <span className="text-[10px] text-slate-500">{kwhAnnual} kWh @ $0.16/kWh</span>
          </div>

          <div className="rounded-lg bg-slate-800/40 border border-slate-700/50 p-4 font-mono">
            <span className="text-[10px] text-slate-400">CARBON EMISSION</span>
            <div className="text-xl font-bold text-slate-200 mt-1 flex items-center gap-1.5">
              <Leaf className="h-4 w-4 text-emerald-400" />
              {carbonFootprintKg} kg CO2e
            </div>
            <span className="text-[10px] text-slate-500">Scope 2 emissions per node</span>
          </div>

          <div className="rounded-lg bg-slate-800/40 border border-slate-700/50 p-4 font-mono">
            <span className="text-[10px] text-slate-400">HARDWARE CAPEX AMORTIZED</span>
            <div className="text-xl font-bold text-cyan-300 mt-1">
              ${(activeHardware.costUsd / 3).toFixed(0)} / yr
            </div>
            <span className="text-[10px] text-slate-500">Over 36-month operational cycle</span>
          </div>
        </div>
      </div>
    </div>
  );
};
