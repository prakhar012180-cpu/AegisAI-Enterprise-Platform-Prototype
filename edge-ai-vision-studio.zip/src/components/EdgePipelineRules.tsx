import React, { useState } from 'react';
import { 
  Zap, 
  ToggleLeft, 
  ToggleRight, 
  Bell, 
  Send, 
  Play, 
  CheckCircle, 
  AlertOctagon, 
  Activity, 
  ShieldAlert,
  Sparkles,
  Radio
} from 'lucide-react';
import { EdgeActionRule } from '../types/edge';

interface EdgePipelineRulesProps {
  onLogTelemetryEvent: (event: any) => void;
}

export const EdgePipelineRules: React.FC<EdgePipelineRulesProps> = ({
  onLogTelemetryEvent,
}) => {
  const [rules, setRules] = useState<EdgeActionRule[]>([
    {
      id: 'rule-1',
      name: 'Pneumatic Reject Ejection (IPC-A-610 Defect)',
      triggerCondition: 'ANY_DEFECT',
      actionType: 'GPIO_PIN',
      actionTarget: 'GPIO Pin 17 (24V Solenoid Cylinder)',
      enabled: true,
      lastTriggered: '12 min ago',
    },
    {
      id: 'rule-2',
      name: 'Hazard Perimeter Alarm Strobe & Horn',
      triggerCondition: 'ZONE_BREACH',
      actionType: 'ALARM_STROBE',
      actionTarget: 'Stacklight Tower 3 (Red Beacon + 95dB Siren)',
      enabled: true,
      lastTriggered: '42 min ago',
    },
    {
      id: 'rule-3',
      name: 'Gemini Cloud Root Cause Deep Audit',
      triggerCondition: 'CONFIDENCE_BELOW_THRESHOLD',
      threshold: 0.75,
      actionType: 'GEMINI_CLOUD_AUDIT',
      actionTarget: 'Gemini 3.8 Flash Vision API Proxy (/api/gemini/edge-audit)',
      enabled: true,
      lastTriggered: '5 min ago',
    },
    {
      id: 'rule-4',
      name: 'Factory SCADA Telemetry Broadcast',
      triggerCondition: 'ANY_DEFECT',
      actionType: 'MQTT_PUBLISH',
      actionTarget: 'mqtt://scada.local:1883/factory/line1/inspection',
      enabled: true,
      lastTriggered: '12 min ago',
    },
  ]);

  const [simulatedTriggerId, setSimulatedTriggerId] = useState<string | null>(null);
  const [simulationStatus, setSimulationStatus] = useState<string | null>(null);

  const toggleRule = (id: string) => {
    setRules((prev) =>
      prev.map((r) => (r.id === id ? { ...r, enabled: !r.enabled } : r))
    );
  };

  const testTriggerRule = async (rule: EdgeActionRule) => {
    setSimulatedTriggerId(rule.id);
    setSimulationStatus(`Executing ${rule.actionTarget}...`);

    // Log to telemetry
    try {
      await fetch('/api/telemetry/log', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          scenario: 'Manual I/O Hardware Simulation',
          hardware: 'Edge GPIO Interface',
          model: 'Edge Rule Evaluator',
          fps: 120,
          latencyMs: 1.2,
          status: rule.actionType === 'GPIO_PIN' ? 'DEFECT' : 'WARN',
          defectType: rule.name,
          confidence: 0.99,
          actionTaken: `Executed Action: ${rule.actionTarget}`,
          auditNotes: `Operator simulated physical trigger via web cockpit. Relay state verified.`,
        }),
      });
      onLogTelemetryEvent({
        scenario: 'Manual I/O Hardware Simulation',
        actionTaken: `Executed Action: ${rule.actionTarget}`,
      });
    } catch (e) {
      console.error(e);
    }

    setTimeout(() => {
      setSimulationStatus(`Action verified: Signal ACK received from ${rule.actionTarget}!`);
      setTimeout(() => {
        setSimulatedTriggerId(null);
        setSimulationStatus(null);
      }, 2500);
    }, 800);
  };

  return (
    <div className="space-y-8">
      {/* Title Card */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <Zap className="h-5 w-5 text-amber-400" />
            Edge Automation I/O & Physical Trigger Rules
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Link computer vision inference classifications directly to physical factory actuators, PLC relays, and MQTT message buses.
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs text-emerald-400 bg-emerald-950/40 px-3 py-1.5 rounded-lg border border-emerald-800/60">
          <Radio className="h-4 w-4 animate-pulse" />
          PLC MODBUS / GPIO ONLINE
        </div>
      </div>

      {simulationStatus && (
        <div className="flex items-center gap-3 rounded-xl border border-amber-500/50 bg-amber-950/40 p-4 text-xs font-mono text-amber-200">
          <Activity className="h-4 w-4 animate-spin text-amber-400" />
          <span>{simulationStatus}</span>
        </div>
      )}

      {/* Rules Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {rules.map((rule) => {
          const isSimulating = simulatedTriggerId === rule.id;

          return (
            <div
              key={rule.id}
              className={`rounded-xl border p-5 transition-all space-y-4 ${
                rule.enabled
                  ? 'bg-slate-900/70 border-slate-700/80'
                  : 'bg-slate-950/40 border-slate-900 opacity-60'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-mono font-semibold text-cyan-400 tracking-wider">
                    {rule.actionType}
                  </span>
                  <h3 className="text-sm font-bold text-white mt-0.5">{rule.name}</h3>
                </div>

                <button
                  onClick={() => toggleRule(rule.id)}
                  className={`text-xl transition-colors ${
                    rule.enabled ? 'text-cyan-400' : 'text-slate-600'
                  }`}
                >
                  {rule.enabled ? (
                    <ToggleRight className="h-6 w-6" />
                  ) : (
                    <ToggleLeft className="h-6 w-6" />
                  )}
                </button>
              </div>

              {/* Condition & Target Specs */}
              <div className="rounded-lg bg-slate-950/80 p-3 border border-slate-800/80 text-xs font-mono space-y-2">
                <div className="flex justify-between">
                  <span className="text-slate-500">WHEN CONDITION:</span>
                  <span className="text-amber-300 font-semibold">{rule.triggerCondition}</span>
                </div>
                {rule.threshold && (
                  <div className="flex justify-between">
                    <span className="text-slate-500">CONFIDENCE THRESHOLD:</span>
                    <span className="text-cyan-300">{(rule.threshold * 100).toFixed(0)}%</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-slate-500">PHYSICAL TARGET:</span>
                  <span className="text-slate-200 font-medium truncate max-w-[200px]" title={rule.actionTarget}>
                    {rule.actionTarget}
                  </span>
                </div>
              </div>

              {/* Action Trigger Buttons */}
              <div className="flex items-center justify-between pt-1">
                <span className="text-[10px] text-slate-500 font-mono">
                  Last Fire: {rule.lastTriggered || 'Idle'}
                </span>

                <button
                  onClick={() => testTriggerRule(rule)}
                  disabled={!rule.enabled || isSimulating}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-medium transition-colors disabled:opacity-40"
                >
                  <Play className={`h-3 w-3 ${isSimulating ? 'text-amber-400 animate-spin' : 'text-cyan-400'}`} />
                  {isSimulating ? 'Simulating...' : 'Test Trigger'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Industrial Pinout Schematic Banner */}
      <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-6 space-y-3">
        <h3 className="text-xs font-semibold text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <Activity className="h-4 w-4 text-cyan-400" />
          Hardware I/O Pinout Mapping (DIN-Rail Optocoupled Terminal)
        </h3>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
          <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
            <span className="text-slate-500 text-[10px]">PIN 17 (DO-1)</span>
            <div className="text-slate-200 font-bold mt-0.5">Solenoid Rejecter</div>
            <div className="text-emerald-400 text-[10px]">24V DC / 0.5A Sink</div>
          </div>
          <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
            <span className="text-slate-500 text-[10px]">PIN 18 (DO-2)</span>
            <div className="text-slate-200 font-bold mt-0.5">Warning Stacklight</div>
            <div className="text-amber-400 text-[10px]">Strobe Active High</div>
          </div>
          <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
            <span className="text-slate-500 text-[10px]">ETH-0 (TCP/IP)</span>
            <div className="text-slate-200 font-bold mt-0.5">Modbus TCP / MQTT</div>
            <div className="text-cyan-400 text-[10px]">1000BASE-T Line 1</div>
          </div>
          <div className="p-3 rounded-lg bg-slate-950/80 border border-slate-800">
            <span className="text-slate-500 text-[10px]">CLOUD REST</span>
            <div className="text-slate-200 font-bold mt-0.5">Gemini Vision Audit</div>
            <div className="text-indigo-400 text-[10px]">HTTPS TLS 1.3</div>
          </div>
        </div>
      </div>
    </div>
  );
};
